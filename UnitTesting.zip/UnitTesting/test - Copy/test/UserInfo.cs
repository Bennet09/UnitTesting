﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    public class UserInfo
    {
        private string name;
        private string location;
        private string studentNumber;
        private double salaryOrBalance;
        private string surname;
        private string areaCode;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Location
        {
            get { return location; }
            set { location = value; }
        }

        public string StudentNumber
        {

            get { return studentNumber; }
            set { studentNumber = value; }
        }

        public double SalaryOrBalance
        {
            get { return salaryOrBalance; }
            set { salaryOrBalance = value; }
        }

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }

        public string AreaCode
        {
            get { return areaCode; }
            set { areaCode = value; }
        }

        public UserInfo(string name, string location, string studentNumber, double salaryOrBalance, string surname, string areaCode)
        {
            Name = name;
            Location = location;
            StudentNumber = studentNumber;
            SalaryOrBalance = salaryOrBalance;
            Surname = surname;
            AreaCode = areaCode;
        }

    }
}
