﻿using test;

internal class Program
{
    private static void Main(string[] args)
    {
        UserInfo defaultInfo = new UserInfo("YourName", "YourLocation", "12345", 1000.0, "YourSurname", "12345");

        Console.WriteLine("Default User Information:");
        PrintUserInfo(defaultInfo);

        UserInfo user = new UserInfo("John Doe", "New York", "98765", 50000.0, "Doe", "54321");

        Console.WriteLine("\nUser Information:");
        PrintUserInfo(user);

        // Update user information using properties
        user.Name = "Jane Doe";
        user.SalaryOrBalance = 75000.0;

        Console.WriteLine("\nUpdated User Information:");
        PrintUserInfo(user);
    }

    static void PrintUserInfo(UserInfo userInfo)
    {
        Console.WriteLine($"Name: {userInfo.Name}");
        Console.WriteLine($"Location: {userInfo.Location}");
        Console.WriteLine($"Student Number: {userInfo.StudentNumber}");
        Console.WriteLine($"Salary/Balance: {userInfo.SalaryOrBalance}");
        Console.WriteLine($"Surname: {userInfo.Surname}");
        Console.WriteLine($"Area Code: {userInfo.AreaCode}");
        Console.WriteLine();
    }


}