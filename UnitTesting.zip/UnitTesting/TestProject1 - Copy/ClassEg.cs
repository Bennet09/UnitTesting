﻿namespace TestProject1
{
    internal class ClassEg
    {
        internal void checkLimit(int theLimit)
        {
            throw new NotImplementedException();
        }

        internal void LessThanZero()
        {
            throw new NotImplementedException();
        }
    }
}