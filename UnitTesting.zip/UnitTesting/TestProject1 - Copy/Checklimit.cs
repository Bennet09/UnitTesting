﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject1
{
    internal class Checklimit
    {
        [TestMethod]
        public void TestLessThanZero()
        {
            //Arrange
            int theLimit = -1;
            ClassEg classEgObject = new ClassEg();

           //Act and Assert
           Assert.ThrowsException<System.ArgumentOutOfRangeException>(() => classEgObject.checkLimit(theLimit));
        }
        
    }
}
